module.exports = {
    default: `--format-options '{"snippetInterface": "synchronous"}'`,
    default: '--publish-quiet'
}
