const {Builder, By, Key, until} = require('selenium-webdriver');
const path = require('path');
const assert = require('assert');

const pathName = path.resolve('demo.html');
const fileURL = encodeURI(`file://${pathName}`)

describe('Testing using Selenium', function() {

    let driver;

    before(async function() {
        driver = await new Builder().forBrowser('safari').build();
    });

    after(function() {
        driver.quit();
    });

    it('Check page title is VOIS', async function(){
        await driver.get(fileURL);
        let pageTitle = await driver.getTitle();
        assert.equal(pageTitle, 'VOIS');
    });

    it('Check page header is Demo Website', async function(){
        await driver.get(fileURL);
        let pageHeader = await driver.findElement(By.xpath("//h1")).getText();
        assert.equal(pageHeader, 'Demo Website');
    });
});