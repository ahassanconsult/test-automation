const {Builder, By, Key, until} = require('selenium-webdriver');
const path = require('path');


const pathName = path.resolve('demo.html');
const fileURL = encodeURI(`file://${pathName}`)

function sleep(millis) {
    return new Promise(resolve => setTimeout(resolve, millis));
}

(async function example() {
    let driver = await new Builder().forBrowser('safari').build();

    
    try {
        // Maximize Window
        await driver.manage().window().maximize();

        await sleep(1000);

        // Navigate to local file Url
        await driver.get(fileURL);

        // Get and print page title
        let pageTitle = await driver.getTitle();
        console.log(`Page title: ${pageTitle}`);

        // Sleep
        await sleep(5000);

        // Enter Username
        await driver.findElement(By.id('txtUsername')).sendKeys('vodafone');

        // Enter Password
        await driver.findElement(By.id('txtPassword')).sendKeys('vodafone');

        // Select Gender
        await driver.findElement(By.id('female')).click();

        // Select Language from Dropdwon list
        let dropdown = driver.findElement(By.id('language'));
        await dropdown.findElement(By.xpath("//option[@value='Italian']")).click();
        //await dropdown.findElement(By.xpath("//option[.='French']")).click();

        // Sleep
        await sleep(3000);

        // Press Button
        await driver.findElement(By.id('btnSubmit')).click();

        // Wait for the alert to be displayed
        await driver.wait(until.alertIsPresent());

        // Store the alert in a variable
        let alert = await driver.switchTo().alert();

        //Store the alert text in a variable
        let alertText = await alert.getText();
        console.log(`Alert text: ${alertText}`);

        // Sleep
        await sleep(2000);

        //Press the OK button
        await alert.accept();

    }
    finally{
        await sleep(5000);
        driver.quit();
    }
})();