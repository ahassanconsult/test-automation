const {Builder, By, Key, until} = require('selenium-webdriver');

function sleep(millis) {
    return new Promise(resolve => setTimeout(resolve, millis));
}

(async function example() {
    let driver = await new Builder().forBrowser('safari').build();
    try {
        

        // Maximize Window
        await driver.manage().window().maximize();
        await sleep(10000);
        // Navigate to Url
        await driver.get('https://www.google.com');

        // Enter text "cheese" and perform keyboard action "Enter"
        await driver.findElement(By.name('q')).sendKeys('cheese', Key.ENTER);

        let firstResult = await driver.wait(until.elementLocated(By.css('h3')), 10000);

        console.log(await firstResult.getAttribute('textContent'));
    }
    finally{
        await sleep(3000);
        driver.quit();
    }
})();