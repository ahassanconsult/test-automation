const assert = require('chai').assert;
const expect = require('chai').expect;
const should = require('chai').should();
var {add, subtract} = require('../myfunctions');


describe('Unit Testing', function() {

    it('01 Test using assert', function(){
        assert.equal(5+6, 11);
    });

    it('02 Test using expect', function(){
        expect(5+6).to.equal(11);
    });

    it.skip('03 Test using should', function(){
        (5+6).should.equal(11);
    });

    it('04 Test Add Function', function(){
        expect(add(3,5)).to.equal(8);
    });

    it('05 Test Subtract Function', function(){
        expect(subtract(3,5)).to.equal(-2);
    });

    it('06 dummy test case');
});