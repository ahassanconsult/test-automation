const chai = require('chai');
const assert = chai.assert;
const expect = chai.expect;
const should = chai.should();
const chaiHttp = require('chai-http');
chai.use(chaiHttp);
const app = require('../server');


describe('Test Server API', function() {

    it('should return Hello World', async function(){
        let res = await chai.request(app).get('/');
        //expect(res).to.have.status(200);
        expect(res.text).to.equal('Hello World');
    });

    // You need to run 'mocha --exit' to end the http server

});