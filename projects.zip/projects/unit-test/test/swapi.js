const assert = require('chai').assert;
const expect = require('chai').expect;
const should = require('chai').should();
var { getPeople } = require('../swapi');



describe('Test Star Wars API for VF Ghana session', function() {
    this.timeout(5000);

    it('should return Luke Skywalker for id value of 1', async function(){
        const name = await getPeople(1);
        expect(name).to.equal('Luke Skywalker');
    });

});