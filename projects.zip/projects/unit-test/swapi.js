const axios = require('axios');

async function getPeople(id) {

    const res = await axios.get(`https://swapi.dev/api/people/${id}/`);
    return res.data.name;

};


module.exports.getPeople = getPeople;