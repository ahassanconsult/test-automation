const iosOpt = {
  path: '/wd/hub',
  host: 'localhost',
  port: 4723,
  capabilities: {
    platformName: "iOS",
    platformVersion: "14.4",
    deviceName: "iPhone 12",
    //app: "https://github.com/cloudgrey-io/the-app/releases/download/v1.10.0/TheApp-v1.10.0.app.zip",
    app: "com.aimanfathi.DemoApp",
    automationName: "XCUITest"
  }
};


const iosWebOpt = {
  path: '/wd/hub',
  host: 'localhost',
  port: 4723,
  capabilities: {
    platformName: "iOS",
    platformVersion: "14.4",
    deviceName: "iPhone 12",
    automationName: "XCUITest",
    browserName: 'Safari'
  }
};


const iosSysOpt = {
  path: '/wd/hub',
  host: 'localhost',
  port: 4723,
  capabilities: {
    platformName: "iOS",
    platformVersion: "14.4",
    deviceName: "iPhone 12",
    app: "com.apple.Preferences",
    automationName: "XCUITest"
  }
};



const androidOpt = {
  path: '/wd/hub',
  host: 'localhost',
  port: 4723,
  capabilities: {
    platformName: "Android",
    platformVersion: "11.0",
    deviceName: "Android Emulator",
    automationName: "UiAutomator2",
    app: "/Users/aymanfathy/Documents/VOIS/VF-Ghana/DemoApp/Artifacts/Android/DemoApp.apk"
    //app: "https://github.com/cloudgrey-io/the-app/releases/download/v1.10.0/TheApp-v1.10.0.apk"
    
  }
};


const androidWebOpt = {
  path: '/wd/hub',
  host: 'localhost',
  port: 4723,
  capabilities: {
    platformName: "Android",
    platformVersion: "11.0",
    deviceName: "Android Emulator",
    automationName: "UiAutomator2",
    browserName: 'Chrome'
  }
};

module.exports = {
  iosOpt,
  iosWebOpt,
  iosSysOpt,
  androidOpt,
  androidWebOpt
};
