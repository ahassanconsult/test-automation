const webdriverio = require('webdriverio');
const config = require('../config/config');


function sleep(millis) {
    return new Promise(resolve => setTimeout(resolve, millis));
}

async function main () {

    // Start Session
    let client = await webdriverio.remote(config.iosSysOpt);

    // Open Settings > General > Dictionary
    const firstScreen = await client.$('~General').click();
    const secondScreen = await client.$('//XCUIElementTypeNavigationBar[@name="General"]');
    await secondScreen.isDisplayed(5000);

    const dict = await client.$('~Dictionary').click();
    const thirdScreen = await client.$('//XCUIElementTypeNavigationBar[@name="Dictionary"]');
    await thirdScreen.isDisplayed(5000);

    // End Session
    await client.deleteSession();
    
}

main();
