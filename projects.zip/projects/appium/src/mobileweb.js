const webdriverio = require('webdriverio');
const config = require('../config/config');


function sleep(millis) {
    return new Promise(resolve => setTimeout(resolve, millis));
}

async function main () {

    // Start Session
    let client = await webdriverio.remote(config.iosWebOpt);

    await sleep(10000);

    // Open URL in browser
    await client.url('https://www.google.com');
    const title = await client.getTitle();
    console.log("URL is: " + title);

    // Sleep 5 seconds
    await sleep(5000);

    // End Session
    await client.deleteSession();
}

main();
