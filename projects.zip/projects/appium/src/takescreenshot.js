const webdriverio = require('webdriverio');
const config = require('../config/config');

function sleep(millis) {
    return new Promise(resolve => setTimeout(resolve, millis));
}


async function main () {


    // Start Session
    let client = await webdriverio.remote(config.iosOpt);

    // Check Home-Screen is displayed
    const homeScreen = await client.$('~home-screen').waitForDisplayed({ timeout: 15000 });

    // App Screenshot
    await client.saveScreenshot('./appshot.png');

    // Element Screenshot
    //const imgElement = await client.$('~reactLogo');
    //const appImage = await imgElement.saveScreenshot('./appshot.png');

    //Sleep
    await sleep(5000);

    // End Session
    await client.deleteSession();
}

main();
