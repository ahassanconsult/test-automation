const webdriverio = require('webdriverio');
const config = require('../config/config');

function sleep(millis) {
    return new Promise(resolve => setTimeout(resolve, millis));
}

async function main () {

    // Start Session
    let client = await webdriverio.remote(config.iosOpt);

    // Check Home-Screen is displayed
    const homeScreen = await client.$('~home-screen').waitForDisplayed({ timeout: 15000 });
    //await homeScreen.isDisplayed(5000);

    // Test failed login
    const textNameElement = await client.$('~txtName');
    await textNameElement.setValue('username');

    const textPassElement = await client.$('~txtPassword');
    await textPassElement.setValue('password');

    const btnLoginElement = await client.$('~btnLogin');
    await btnLoginElement.click();

    const alertText = await client.getAlertText();
    const alertMessage = alertText.split('\n')[1];
    console.log('Alert text: ' + alertMessage);
    await client.dismissAlert();

    // Test successful login
    await textNameElement.setValue('\b\b\b\b\b\b\b\b');
    await textNameElement.setValue('vodafone');
    await textPassElement.setValue('\b\b\b\b\b\b\b\b');
    await textPassElement.setValue('vodafone');
    await btnLoginElement.click();

    await sleep(5000);
    
    // End Session
    await client.deleteSession();
}

main();
