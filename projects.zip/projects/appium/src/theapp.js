const webdriverio = require('webdriverio');
const config = require('../config/config');


function sleep(millis) {
    return new Promise(resolve => setTimeout(resolve, millis));
}

async function main () {

    // Start Session
    let client = await webdriverio.remote(config.androidOpt);

    // Login Screen
    const loginScreen = await client.$('~Login Screen');
    await loginScreen.click();

    const txtUsername = await client.$('~username');
    await txtUsername.setValue('alice');

    const txtPassword = await client.$('~password');
    await txtPassword.setValue('mypassword');

    await client.hideKeyboard();

    const loginButton = await client.$('~loginBtn');
    await loginButton.click();

    const secretArea = await client.$('~Secret Area');
    await secretArea.isDisplayed(5000);

    await sleep(5000);

    // End Session
    await client.deleteSession();
    
}

main();


// -- Echo Box
// The App //back
// messageInput
// messageSaveBtn


// -- Login Screen
// username
// password
// loginBtn
// alice/mypassword