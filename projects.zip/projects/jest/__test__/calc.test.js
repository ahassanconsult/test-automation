var {add, subtract} = require('../calc');


describe('Unit Testing', function() {

    it('Test Add Function', function(){
        expect(add(3,5)).toEqual(8);
    });

    it('Test Subtract Function', function(){
        expect(subtract(3,5)).toEqual(-2);
    });
});