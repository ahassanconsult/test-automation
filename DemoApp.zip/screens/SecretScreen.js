import React, { Component } from 'react';
import { StyleSheet, Text, View, Button, TextInput, Alert } from 'react-native';

class Secret extends Component {
    
    render() {
        return(
            <View style={styles.container}>
                <Text style={styles.txtTitle}>Secret Area</Text>
                <Text>You are logged in</Text>
            </View>
        );
    }
};

export default Secret;


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        padding: 20,
        alignItems: 'center',
        //justifyContent: 'center',
    },
    txtTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        marginBottom: 20
      },
  });