import React, { Component } from 'react';
import { StyleSheet, Text, View, Button, TextInput, Alert } from 'react-native';


class Home extends Component {

    constructor(props) {
        super(props);

        this.state = {
            username: '',
            password: ''
        };

        this.handleSubmit = this.handleSubmit.bind(this);
    };

    

    handleSubmit({navigation}) {
        if (this.state.username=='vodafone' && this.state.password=='vodafone') {
            this.props.navigation.navigate('Secret');
        }
        else {
            Alert.alert(
                'DemoApp',
                'Invalid username or password',
                [{text: 'Cancel'}, {text: 'Ok'}]
            );
        }
    };

    render() {
        return(
            <View style={styles.container} testID="home-screen" accessibilityLabel="home-screen">
                <Text testID="txtHome" accessibilityLabel="txtHome">Home</Text>
                <TextInput
                    onChangeText={(username) => {this.setState({username: username})}}
                    value={this.state.username}
                    style={styles.input}
                    placeholder="Enter your name"
                    testID="txtName"
                    accessibilityLabel="txtName"
                />
                <TextInput
                    onChangeText={(password) => {this.setState({password: password})}}
                    value={this.state.password}
                    style={styles.input}
                    placeholder="Enter your password"
                    testID="txtPassword"
                    accessibilityLabel="txtPassword"
                />
                <Button
                    onPress={this.handleSubmit}
                    title="Login"
                    color="#841584"
                    testID="btnLogin"
                    accessibilityLabel="btnLogin"
                />
          </View>
        );
    }
};

export default Home;


const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        paddingTop: 50
        //justifyContent: 'center',
    },
    input: {
        width: '60%',
        height: 25,
        margin: 12,
        borderWidth: 1,
      },
  });